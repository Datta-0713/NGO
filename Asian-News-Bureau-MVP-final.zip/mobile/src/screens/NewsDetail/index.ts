export * from './NewsDetailScreen';
